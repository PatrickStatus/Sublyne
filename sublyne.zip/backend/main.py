from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.api.endpoints import auth, tunnel, stats
from app.core.config import settings
from app.db.init_db import init_db
from app.utils.traffic_monitor import TrafficMonitor
import uvicorn
import logging
from connection_monitor import connection_monitor
from resource_monitor import resource_monitor
import asyncio

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize traffic monitor
traffic_monitor = TrafficMonitor()

app = FastAPI(
    title=settings.PROJECT_NAME,
    description="Sublyne API for tunneling traffic",
    version="0.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# Set up CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # در محیط تولید باید محدود شود
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api", tags=["authentication"])
app.include_router(tunnel.router, prefix="/api", tags=["modify tunnel"])
app.include_router(stats.router, prefix="/api", tags=["stats"])

@app.on_event("startup")
async def startup_event():
    try:
        # Initialize database
        init_db()
        logger.info("Database initialized successfully")
        
        # Start traffic monitoring
        traffic_monitor.start_monitoring()
        logger.info("Traffic monitoring started successfully")
        
        # Start monitoring systems
        asyncio.create_task(connection_monitor.start_monitoring())
        asyncio.create_task(resource_monitor.start_monitoring())
        
        logger.info("All monitoring systems started")
        
    except Exception as e:
        logger.error(f"Error during startup: {e}")
        # Don't raise the exception to prevent app from crashing

@app.on_event("shutdown")
async def shutdown_event():
    try:
        # Stop monitoring systems
        connection_monitor.stop_monitoring()
        resource_monitor.stop_monitoring()
        traffic_monitor.stop_monitoring()
        
        logger.info("All monitoring systems stopped")
        
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)