import asyncio
import subprocess
import logging
from datetime import datetime
from sqlalchemy.orm import Session
from app.db.init_db import get_database
from app.models.tunnel import Tunnel

logger = logging.getLogger(__name__)

class ConnectionMonitor:
    def __init__(self):
        self.running = False
    
    async def ping_host(self, host: str, count: int = 4) -> float:
        """Ping a host and return packet loss percentage"""
        try:
            # Run ping command
            result = subprocess.run(
                ["ping", "-n", str(count), host],
                capture_output=True,
                text=True,
                timeout=30
            )
            
            if result.returncode == 0:
                # Parse ping output to get packet loss
                output = result.stdout
                for line in output.split('\n'):
                    if 'loss' in line.lower():
                        # Extract packet loss percentage
                        import re
                        match = re.search(r'\((\d+)%.*loss\)', line)
                        if match:
                            return float(match.group(1))
                return 0.0  # No loss detected
            else:
                return 100.0  # Complete failure
                
        except Exception as e:
            logger.error(f"Error pinging {host}: {e}")
            return 100.0
    
    async def check_tunnel_connections(self):
        """Check connection status for all active tunnels"""
        db = next(get_database())
        try:
            # Get all active tunnels with dest_private_ip
            tunnels = db.query(Tunnel).filter(
                Tunnel.is_active == True,
                Tunnel.dest_private_ip.isnot(None)
            ).all()
            
            for tunnel in tunnels:
                try:
                    # Ping dest_private_ip
                    packet_loss = await self.ping_host(tunnel.dest_private_ip)
                    
                    # Update tunnel connection status
                    tunnel.connection = packet_loss
                    tunnel.last_connection_check = datetime.utcnow()
                    
                    logger.info(f"Tunnel {tunnel.interface}: {packet_loss}% packet loss")
                    
                except Exception as e:
                    logger.error(f"Error checking connection for tunnel {tunnel.interface}: {e}")
                    tunnel.connection = 100.0
                    tunnel.last_connection_check = datetime.utcnow()
            
            db.commit()
            
        except Exception as e:
            logger.error(f"Error in connection monitoring: {e}")
            db.rollback()
        finally:
            db.close()
    
    async def start_monitoring(self):
        """Start connection monitoring loop"""
        self.running = True
        logger.info("Connection monitoring started")
        
        while self.running:
            try:
                await self.check_tunnel_connections()
                await asyncio.sleep(60)  # Check every 60 seconds
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(60)
    
    def stop_monitoring(self):
        """Stop connection monitoring"""
        self.running = False
        logger.info("Connection monitoring stopped")

# Global monitor instance
connection_monitor = ConnectionMonitor()

if __name__ == "__main__":
    asyncio.run(connection_monitor.start_monitoring())