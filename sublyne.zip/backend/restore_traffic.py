#!/usr/bin/env python3
"""
Script to restore iptables rules and start traffic monitoring after reboot
"""

import sys
import os

# Add the backend directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from app.utils.traffic_monitor import traffic_monitor

if __name__ == "__main__":
    try:
        print("Restoring iptables rules...")
        traffic_monitor.restore_iptables_rules()
        
        print("Starting traffic monitoring...")
        traffic_monitor.start_monitoring()
        
        print("Traffic monitoring system restored successfully!")
        
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)