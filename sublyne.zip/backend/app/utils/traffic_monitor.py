import subprocess
import time
import threading
from datetime import datetime, timedelta
from typing import Dict, List
from sqlalchemy.orm import Session
from app.models.tunnel import Tunnel
from app.models.traffic_stats import TrafficStats
from app.db.init_db import get_database
import logging

logger = logging.getLogger(__name__)

class TrafficMonitor:
    def __init__(self):
        self.monitoring = False
        self.monitor_thread = None
        self.check_interval = 300  # 5 minutes
        
    def setup_iptables_rules(self, ports: str):
        """Setup iptables rules for traffic monitoring"""
        try:
            port_list = [p.strip() for p in ports.split(',') if p.strip()]
            
            for port in port_list:
                # Input traffic
                subprocess.run([
                    "iptables", "-I", "INPUT", "-p", "tcp", "--dport", port, 
                    "-j", "ACCEPT"
                ], check=True)
                
                # Output traffic
                subprocess.run([
                    "iptables", "-I", "OUTPUT", "-p", "tcp", "--sport", port, 
                    "-j", "ACCEPT"
                ], check=True)
                
            logger.info(f"Iptables rules setup for ports: {ports}")
            
        except Exception as e:
            logger.error(f"Error setting up iptables rules: {e}")
    
    def get_port_traffic(self, port: str) -> Dict[str, float]:
        """Get traffic statistics for a specific port"""
        try:
            # Get input traffic
            result_in = subprocess.run([
                "iptables", "-L", "INPUT", "-v", "-n", "-x"
            ], capture_output=True, text=True, check=True)
            
            # Get output traffic
            result_out = subprocess.run([
                "iptables", "-L", "OUTPUT", "-v", "-n", "-x"
            ], capture_output=True, text=True, check=True)
            
            bytes_in = self._parse_iptables_output(result_in.stdout, port)
            bytes_out = self._parse_iptables_output(result_out.stdout, port)
            
            return {
                'bytes_in': bytes_in,
                'bytes_out': bytes_out,
                'total_bytes': bytes_in + bytes_out
            }
            
        except Exception as e:
            logger.error(f"Error getting traffic for port {port}: {e}")
            return {'bytes_in': 0.0, 'bytes_out': 0.0, 'total_bytes': 0.0}
    
    def _parse_iptables_output(self, output: str, port: str) -> float:
        """Parse iptables output to extract bytes for specific port"""
        lines = output.split('\n')
        for line in lines:
            if f"dpt:{port}" in line or f"spt:{port}" in line:
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        return float(parts[1])  # bytes column
                    except ValueError:
                        continue
        return 0.0
    
    def collect_tunnel_traffic(self, tunnel: Tunnel) -> Dict[str, float]:
        """Collect traffic statistics for a tunnel"""
        total_traffic = {'bytes_in': 0.0, 'bytes_out': 0.0, 'total_bytes': 0.0}
        
        if tunnel.origin_ports:
            port_list = [p.strip() for p in tunnel.origin_ports.split(',') if p.strip()]
            
            for port in port_list:
                port_traffic = self.get_port_traffic(port)
                total_traffic['bytes_in'] += port_traffic['bytes_in']
                total_traffic['bytes_out'] += port_traffic['bytes_out']
                total_traffic['total_bytes'] += port_traffic['total_bytes']
        
        return total_traffic
    
    def save_hourly_stats(self, tunnel: Tunnel, traffic_data: Dict[str, float]):
        """Save hourly traffic statistics"""
        try:
            db = next(get_database())
            
            now = datetime.utcnow()
            hour_start = now.replace(minute=0, second=0, microsecond=0)
            hour_end = hour_start + timedelta(hours=1)
            
            # Check if hourly record exists
            existing_stat = db.query(TrafficStats).filter(
                TrafficStats.tunnel_id == tunnel.id,
                TrafficStats.period_type == 'hourly',
                TrafficStats.period_start == hour_start
            ).first()
            
            if existing_stat:
                # Update existing record
                existing_stat.bytes_in = traffic_data['bytes_in']
                existing_stat.bytes_out = traffic_data['bytes_out']
                existing_stat.total_bytes = traffic_data['total_bytes']
                existing_stat.updated_at = now
            else:
                # Create new record
                new_stat = TrafficStats(
                    tunnel_id=tunnel.id,
                    bytes_in=traffic_data['bytes_in'],
                    bytes_out=traffic_data['bytes_out'],
                    total_bytes=traffic_data['total_bytes'],
                    period_type='hourly',
                    period_start=hour_start,
                    period_end=hour_end
                )
                db.add(new_stat)
            
            db.commit()
            
        except Exception as e:
            logger.error(f"Error saving hourly stats: {e}")
        finally:
            db.close()
    
    def save_daily_stats(self, tunnel: Tunnel):
        """Aggregate and save daily traffic statistics"""
        try:
            db = next(get_database())
            
            now = datetime.utcnow()
            day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = day_start + timedelta(days=1)
            
            # Aggregate hourly stats for the day
            hourly_stats = db.query(TrafficStats).filter(
                TrafficStats.tunnel_id == tunnel.id,
                TrafficStats.period_type == 'hourly',
                TrafficStats.period_start >= day_start,
                TrafficStats.period_start < day_end
            ).all()
            
            total_bytes_in = sum(stat.bytes_in for stat in hourly_stats)
            total_bytes_out = sum(stat.bytes_out for stat in hourly_stats)
            total_bytes = total_bytes_in + total_bytes_out
            
            # Check if daily record exists
            existing_daily = db.query(TrafficStats).filter(
                TrafficStats.tunnel_id == tunnel.id,
                TrafficStats.period_type == 'daily',
                TrafficStats.period_start == day_start
            ).first()
            
            if existing_daily:
                # Update existing record
                existing_daily.bytes_in = total_bytes_in
                existing_daily.bytes_out = total_bytes_out
                existing_daily.total_bytes = total_bytes
                existing_daily.updated_at = now
            else:
                # Create new record
                new_daily = TrafficStats(
                    tunnel_id=tunnel.id,
                    bytes_in=total_bytes_in,
                    bytes_out=total_bytes_out,
                    total_bytes=total_bytes,
                    period_type='daily',
                    period_start=day_start,
                    period_end=day_end
                )
                db.add(new_daily)
            
            db.commit()
            
        except Exception as e:
            logger.error(f"Error saving daily stats: {e}")
        finally:
            db.close()
    
    def monitor_traffic(self):
        """Main monitoring loop"""
        while self.monitoring:
            try:
                db = next(get_database())
                active_tunnels = db.query(Tunnel).filter(Tunnel.is_active == True).all()
                
                for tunnel in active_tunnels:
                    # Collect current traffic
                    traffic_data = self.collect_tunnel_traffic(tunnel)
                    
                    # Update tunnel's current usage
                    tunnel.traffic_usage = traffic_data['total_bytes'] / (1024**3)  # Convert to GB
                    tunnel.last_traffic_check = datetime.utcnow()
                    
                    # Check traffic limit
                    if tunnel.traffic_limit and tunnel.traffic_usage >= tunnel.traffic_limit:
                        tunnel.is_traffic_limited = True
                        logger.warning(f"Tunnel {tunnel.number} reached traffic limit")
                    
                    # Save hourly stats
                    self.save_hourly_stats(tunnel, traffic_data)
                    
                    # Save daily stats (aggregate from hourly)
                    self.save_daily_stats(tunnel)
                
                db.commit()
                db.close()
                
            except Exception as e:
                logger.error(f"Error in traffic monitoring: {e}")
            
            time.sleep(self.check_interval)
    
    def start_monitoring(self):
        """Start traffic monitoring"""
        if not self.monitoring:
            self.monitoring = True
            self.monitor_thread = threading.Thread(target=self.monitor_traffic)
            self.monitor_thread.daemon = True
            self.monitor_thread.start()
            logger.info("Traffic monitoring started")
    
    def stop_monitoring(self):
        """Stop traffic monitoring"""
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join()
        logger.info("Traffic monitoring stopped")
    
    def restore_iptables_rules(self):
        """Restore iptables rules for all active tunnels after reboot"""
        try:
            from app.models.tunnel import Tunnel
            from app.db.database import get_database
            
            db = next(get_database())
            active_tunnels = db.query(Tunnel).filter(Tunnel.is_active == True).all()
            
            restored_count = 0
            for tunnel in active_tunnels:
                if tunnel.origin_ports:
                    self.setup_iptables_rules(tunnel.origin_ports)
                    restored_count += 1
            
            db.close()
            logger.info(f"Restored iptables rules for {restored_count} active tunnels")
            
        except Exception as e:
            logger.error(f"Error restoring iptables rules: {e}")
            raise

# Global instance
traffic_monitor = TrafficMonitor()