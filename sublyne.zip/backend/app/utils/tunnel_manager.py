import os
import subprocess
import json
import requests
from typing import Dict, List, Optional
from sqlalchemy.orm import Session
from app.models.tunnel import Tunnel
from app.core.config import settings
import logging

logger = logging.getLogger(__name__)

class TunnelManager:
    def __init__(self, db: Session):
        self.db = db
        self.templates_path = "d:\\Sublyne\\backend\\templates"
        self.gost_binary = "/usr/local/bin/gost"
        
    def generate_private_ips(self, number: int) -> tuple:
        """Generate private IPs based on tunnel number"""
        origin_ip = f"10.10.{number}.1"
        dest_ip = f"10.10.{number}.2"
        return origin_ip, dest_ip
    
    def create_tunnel_service(self, tunnel: Tunnel) -> bool:
        """Create and start tunnel service"""
        try:
            # Read appropriate shell script
            script_file = "origin.sh.tmpl" if tunnel.server_type == "origin" else "dest.sh.tmpl"
            script_path = os.path.join(self.templates_path, tunnel.tunnel_type, script_file)
            
            if not os.path.exists(script_path):
                logger.error(f"Script file not found: {script_path}")
                return False
                
            with open(script_path, 'r') as f:
                script_content = f.read()
            
            # Replace variables in script
            script_content = self.replace_script_variables(script_content, tunnel)
            
            # Create service file
            service_name = f"tunnel-{tunnel.number}"
            service_content = f"""[Unit]
Description=Tunnel {tunnel.number} ({tunnel.tunnel_type})
After=network.target

[Service]
Type=oneshot
RemainAfterExit=yes
ExecStart=/bin/bash -c '{script_content}'
ExecStop=/bin/bash {self.templates_path}/{tunnel.tunnel_type}/stop.{tunnel.server_type}.sh.tmpl
Restart=on-failure

[Install]
WantedBy=multi-user.target
"""
            
            # Write service file
            service_file_path = f"/etc/systemd/system/{service_name}.service"
            with open(service_file_path, 'w') as f:
                f.write(service_content)
            
            # Enable and start service
            subprocess.run(["systemctl", "daemon-reload"], check=True)
            subprocess.run(["systemctl", "enable", service_name], check=True)
            subprocess.run(["systemctl", "start", service_name], check=True)
            
            tunnel.service_name = service_name
            return True
            
        except Exception as e:
            logger.error(f"Error creating tunnel service: {e}")
            return False
    
    def create_gost_service(self, tunnel: Tunnel) -> bool:
        """Create and start gost forwarding service"""
        if tunnel.server_type != "origin":
            return True  # Only origin servers need gost forwarding
            
        try:
            # Parse ports
            origin_ports = [p.strip() for p in tunnel.origin_ports.split(',') if p.strip()]
            dest_ports = [p.strip() for p in tunnel.dest_ports.split(',') if p.strip()]
            
            if len(origin_ports) != len(dest_ports):
                logger.error("Origin and destination ports count mismatch")
                return False
            
            # Create gost configuration
            gost_config = []
            for i, (origin_port, dest_port) in enumerate(zip(origin_ports, dest_ports)):
                gost_config.append(f"-L=:{origin_port} -F=tcp://{tunnel.dest_private_ip}:{dest_port}")
            
            gost_args = " ".join(gost_config)
            
            # Create gost service
            gost_service_name = f"gost-tunnel-{tunnel.number}"
            gost_service_content = f"""[Unit]
Description=Gost Tunnel {tunnel.number} Traffic Forwarding
After=network.target

[Service]
Type=simple
User=root
ExecStart={self.gost_binary} {gost_args}
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
"""
            
            # Write gost service file
            gost_service_file = f"/etc/systemd/system/{gost_service_name}.service"
            with open(gost_service_file, 'w') as f:
                f.write(gost_service_content)
            
            # Enable and start gost service
            subprocess.run(["systemctl", "daemon-reload"], check=True)
            subprocess.run(["systemctl", "enable", gost_service_name], check=True)
            subprocess.run(["systemctl", "start", gost_service_name], check=True)
            
            tunnel.gost_service_name = gost_service_name
            return True
            
        except Exception as e:
            logger.error(f"Error creating gost service: {e}")
            return False
    
    def replace_script_variables(self, script_content: str, tunnel: Tunnel) -> str:
        """Replace variables in shell script with tunnel data"""
        replacements = {
            '{{number}}': str(tunnel.number),
            '{{interface}}': tunnel.interface or '',
            '{{tunnel_type}}': tunnel.tunnel_type,
            '{{server_type}}': tunnel.server_type,
            '{{ip_origin}}': tunnel.ip_origin or '',
            '{{ip_dest}}': tunnel.ip_dest or '',
            '{{tun_port}}': str(tunnel.tun_port) if tunnel.tun_port else '',
            '{{key}}': tunnel.key or '',
            '{{origin_ports}}': tunnel.origin_ports or '',
            '{{dest_ports}}': tunnel.dest_ports or '',
            '{{origin_private_ip}}': tunnel.origin_private_ip or '',
            '{{dest_private_ip}}': tunnel.dest_private_ip or '',
        }
        
        for placeholder, value in replacements.items():
            script_content = script_content.replace(placeholder, value)
        
        return script_content
    
    def stop_tunnel(self, tunnel: Tunnel) -> bool:
        """Stop tunnel and gost services"""
        try:
            # Stop and disable tunnel service
            if tunnel.service_name:
                subprocess.run(["systemctl", "stop", tunnel.service_name], check=True)
                subprocess.run(["systemctl", "disable", tunnel.service_name], check=True)
            
            # Stop and disable gost service
            if tunnel.gost_service_name:
                subprocess.run(["systemctl", "stop", tunnel.gost_service_name], check=True)
                subprocess.run(["systemctl", "disable", tunnel.gost_service_name], check=True)
            
            # Run stop script
            stop_script = f"stop.{tunnel.server_type}.sh.tmpl"
            stop_script_path = os.path.join(self.templates_path, tunnel.tunnel_type, stop_script)
            
            if os.path.exists(stop_script_path):
                with open(stop_script_path, 'r') as f:
                    stop_script_content = f.read()
                
                stop_script_content = self.replace_script_variables(stop_script_content, tunnel)
                subprocess.run(["bash", "-c", stop_script_content], check=True)
            
            tunnel.is_active = False
            return True
            
        except Exception as e:
            logger.error(f"Error stopping tunnel: {e}")
            return False
    
    def start_tunnel(self, tunnel: Tunnel) -> bool:
        """Start tunnel and gost services"""
        try:
            # Run start script
            start_script = f"start.{tunnel.server_type}.sh.tmpl"
            start_script_path = os.path.join(self.templates_path, tunnel.tunnel_type, start_script)
            
            if os.path.exists(start_script_path):
                with open(start_script_path, 'r') as f:
                    start_script_content = f.read()
                
                start_script_content = self.replace_script_variables(start_script_content, tunnel)
                subprocess.run(["bash", "-c", start_script_content], check=True)
            
            # Enable and start tunnel service
            if tunnel.service_name:
                subprocess.run(["systemctl", "enable", tunnel.service_name], check=True)
                subprocess.run(["systemctl", "start", tunnel.service_name], check=True)
            
            # Enable and start gost service
            if tunnel.gost_service_name:
                subprocess.run(["systemctl", "enable", tunnel.gost_service_name], check=True)
                subprocess.run(["systemctl", "start", tunnel.gost_service_name], check=True)
            
            tunnel.is_active = True
            tunnel.is_traffic_limited = False
            return True
            
        except Exception as e:
            logger.error(f"Error starting tunnel: {e}")
            return False
    
    def delete_tunnel(self, tunnel: Tunnel) -> bool:
        """Completely delete tunnel, services, and cleanup"""
        try:
            # Stop and disable tunnel service
            if tunnel.service_name:
                subprocess.run(["systemctl", "stop", tunnel.service_name], check=False)
                subprocess.run(["systemctl", "disable", tunnel.service_name], check=False)
                
                # Remove service file
                service_file_path = f"/etc/systemd/system/{tunnel.service_name}.service"
                if os.path.exists(service_file_path):
                    os.remove(service_file_path)
            
            # Stop and disable gost service
            if tunnel.gost_service_name:
                subprocess.run(["systemctl", "stop", tunnel.gost_service_name], check=False)
                subprocess.run(["systemctl", "disable", tunnel.gost_service_name], check=False)
                
                # Remove gost service file
                gost_service_file = f"/etc/systemd/system/{tunnel.gost_service_name}.service"
                if os.path.exists(gost_service_file):
                    os.remove(gost_service_file)
            
            # Run delete script
            delete_script = f"delete.{tunnel.server_type}.sh.tmpl"
            delete_script_path = os.path.join(self.templates_path, tunnel.tunnel_type, delete_script)
            
            if os.path.exists(delete_script_path):
                with open(delete_script_path, 'r') as f:
                    delete_script_content = f.read()
                
                delete_script_content = self.replace_script_variables(delete_script_content, tunnel)
                subprocess.run(["bash", "-c", delete_script_content], check=False)
            
            # Reload systemd daemon
            subprocess.run(["systemctl", "daemon-reload"], check=False)
            
            # Remove iptables rules if origin server
            if tunnel.server_type == "origin" and tunnel.origin_ports:
                from app.utils.traffic_monitor import traffic_monitor
                traffic_monitor.remove_iptables_rules(tunnel.origin_ports)
            
            return True
            
        except Exception as e:
            logger.error(f"Error deleting tunnel: {e}")
            return False