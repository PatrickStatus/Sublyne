from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from app.models import Base, User, Tunnel
from app.core.config import settings
from app.utils.security import get_password_hash
import os

# Create database directory if it doesn't exist
# Use synchronous SQLite URL instead of async
sync_db_url = settings.DATABASE_URL.replace("sqlite+aiosqlite://", "sqlite:///")
db_dir = os.path.dirname(sync_db_url.replace("sqlite:///", ""))
if not os.path.exists(db_dir):
    os.makedirs(db_dir)

engine = create_engine(sync_db_url)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    """Database dependency for FastAPI"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def get_database():
    """Get database session (non-generator version)"""
    return SessionLocal()

def init_db():
    # Create all tables
    Base.metadata.create_all(bind=engine)
    
    db = SessionLocal()
    
    try:
        # Check if admin user exists
        admin_user = db.query(User).filter(User.username == "admin").first()
        if not admin_user:
            # Create admin user
            admin_user = User(
                username="admin",
                hashed_password=get_password_hash("admin"),
                is_active=True,
                is_superuser=True
            )
            db.add(admin_user)
            db.commit()
            print("Admin user created successfully")
        else:
            print("Admin user already exists")
            
    except Exception as e:
        print(f"Error initializing database: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    init_db()