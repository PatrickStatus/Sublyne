import os
import secrets
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    PROJECT_NAME: str = "Sublyne"
    API_V1_STR: str = "/api"
    SECRET_KEY: str = secrets.token_urlsafe(32)
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24  # 24 ساعت
    # استفاده از مسیر مطلق برای دیتابیس
    BASE_DIR: str = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    DATABASE_URL: str = f"sqlite:///{os.path.join(BASE_DIR, 'database', 'sublyne.db')}"

    class Config:
        env_file = ".env"

settings = Settings()