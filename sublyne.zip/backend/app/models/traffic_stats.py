from sqlalchemy import Boolean, Column, Integer, String, Float, DateTime, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
from .tunnel import Base

class TrafficStats(Base):
    __tablename__ = "traffic_stats"

    id = Column(Integer, primary_key=True, index=True)
    tunnel_id = Column(Integer, ForeignKey("tunnels.id"), nullable=False)
    
    # Traffic data
    bytes_in = Column(Float, default=0.0)  # Incoming traffic in bytes
    bytes_out = Column(Float, default=0.0)  # Outgoing traffic in bytes
    total_bytes = Column(Float, default=0.0)  # Total traffic in bytes
    
    # Time period
    period_type = Column(String, nullable=False)  # 'hourly' or 'daily'
    period_start = Column(DateTime, nullable=False)  # Start of the period
    period_end = Column(DateTime, nullable=False)  # End of the period
    
    # Metadata
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship
    tunnel = relationship("Tunnel", back_populates="traffic_stats")