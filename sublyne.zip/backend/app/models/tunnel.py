from sqlalchemy import Boolean, Column, Integer, String, Float, DateTime, Text, event
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime
import hashlib
import secrets
import string

Base = declarative_base()

class Tunnel(Base):
    __tablename__ = "tunnels"

    id = Column(Integer, primary_key=True, index=True)
    number = Column(Integer, unique=True, index=True)  # Tunnel number
    interface = Column(String, nullable=True)  # Network interface
    interface_salt = Column(String, nullable=True, unique=True, index=True)  # MD5 hash of interface
    random_phrase = Column(String, nullable=True, unique=True, index=True)  # Random 16-character phrase
    tunnel_type = Column(String, nullable=False)  # gre, vxlan, etc.
    server_type = Column(String, nullable=False)  # origin or dest
    ip_origin = Column(String, nullable=True)  # Origin IP
    ip_dest = Column(String, nullable=True)  # Destination IP
    tun_port = Column(Integer, nullable=True)  # Tunnel port
    key = Column(String, nullable=True)  # Tunnel key
    origin_ports = Column(String, nullable=True)  # Comma-separated ports
    dest_ports = Column(String, nullable=True)  # Comma-separated ports
    forward_method = Column(String, default="gost")  # Forward method (gost, etc.)
    traffic_limit = Column(Float, nullable=True)  # Traffic limit in GB
    
    # Auto-generated fields
    origin_private_ip = Column(String, nullable=True)  # 10.10.{number}.1
    dest_private_ip = Column(String, nullable=True)  # 10.10.{number}.2
    traffic_usage = Column(Float, default=0.0)  # Current traffic usage in GB
    
    # Service management
    service_name = Column(String, nullable=True)  # System service name
    gost_service_name = Column(String, nullable=True)  # Gost service name
    is_active = Column(Boolean, default=True)  # Tunnel status
    is_traffic_limited = Column(Boolean, default=False)  # Traffic limit reached
    
    # New monitoring fields
    status = Column(String, default="unknown")  # Gost service status: running, stopped, error, unknown
    connection = Column(Float, nullable=True)  # Ping packet loss percentage to dest_private_ip
    cpu_usage = Column(Float, default=0.0)  # CPU usage of gost service
    ram_usage = Column(Float, default=0.0)  # RAM usage of gost service in MB
    
    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_traffic_check = Column(DateTime, nullable=True)
    last_connection_check = Column(DateTime, nullable=True)
    last_resource_check = Column(DateTime, nullable=True)
    
    # Relationship
    traffic_stats = relationship("TrafficStats", back_populates="tunnel")
    
    def generate_interface_salt(self):
        """Generate MD5 hash of interface as salt"""
        if self.interface:
            return hashlib.md5(self.interface.encode()).hexdigest()
        return None
    
    def generate_random_phrase(self):
        """Generate random 16-character phrase with numbers and letters"""
        characters = string.ascii_letters + string.digits  # a-z, A-Z, 0-9
        return ''.join(secrets.choice(characters) for _ in range(16))
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.interface and not self.interface_salt:
            self.interface_salt = self.generate_interface_salt()
        if not self.random_phrase:
            self.random_phrase = self.generate_random_phrase()

# Event listener to automatically update interface_salt when interface changes
@event.listens_for(Tunnel.interface, 'set')
def update_interface_salt(target, value, oldvalue, initiator):
    """Automatically update interface_salt when interface is set or changed"""
    if value and value != oldvalue:
        target.interface_salt = hashlib.md5(value.encode()).hexdigest()

# Event listener for before_insert to ensure interface_salt and random_phrase are set
@event.listens_for(Tunnel, 'before_insert')
def set_fields_before_insert(mapper, connection, target):
    """Ensure interface_salt and random_phrase are set before inserting new tunnel"""
    if target.interface and not target.interface_salt:
        target.interface_salt = hashlib.md5(target.interface.encode()).hexdigest()
    if not target.random_phrase:
        target.random_phrase = target.generate_random_phrase()

# Event listener for before_update to ensure interface_salt is updated
@event.listens_for(Tunnel, 'before_update')
def update_interface_salt_before_update(mapper, connection, target):
    """Ensure interface_salt is updated when interface changes"""
    if target.interface and not target.interface_salt:
        target.interface_salt = hashlib.md5(target.interface.encode()).hexdigest()