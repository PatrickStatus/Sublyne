from fastapi import APIRouter
from app.api.endpoints import auth, tunnel, tunnel_status

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["authentication"])
api_router.include_router(tunnel.router, prefix="/tunnels", tags=["tunnels"])
api_router.include_router(tunnel_status.router, prefix="/status", tags=["tunnel-status"])