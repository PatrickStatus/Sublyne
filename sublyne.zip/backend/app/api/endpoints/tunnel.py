import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.core.security import get_current_user
from app.models.user import User
from app.models.tunnel import Tunnel
from app.db.init_db import get_database
from app.utils.tunnel_manager import TunnelManager
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter()

class TunnelTypeResponse(BaseModel):
    success: bool
    message: str
    tunnel_types: List[str]
    count: int

class TunnelRequirementsRequest(BaseModel):
    tunnel_type: str
    server_type: str  # "origin" or "dest"

class TunnelRequirementsResponse(BaseModel):
    success: bool
    message: str
    tunnel_type: str
    server_type: str
    fields: List[Dict[str, Any]]

class AddTunnelRequest(BaseModel):
    number: Optional[str] = None
    interface: Optional[str] = None
    tunnel_type: str
    server_type: str  # "origin" or "dest"
    ip_origin: Optional[str] = None
    ip_dest: Optional[str] = None
    tun_port: Optional[str] = None
    key: Optional[str] = None
    origin_ports: Optional[str] = None
    dest_ports: Optional[str] = None
    forward_method: Optional[str] = None
    traffic_limit: Optional[str] = None

class AddTunnelResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[str] = None

class EditTunnelRequest(BaseModel):
    interface: str
    traffic_limit: float

class EditTunnelResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[int] = None
    old_traffic_limit: Optional[float] = None
    new_traffic_limit: Optional[float] = None
    tunnel_restarted: Optional[bool] = False

class DeleteTunnelRequest(BaseModel):
    interface: str

class DeleteTunnelResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[int] = None
    deleted_services: List[str] = []

class StopTunnelRequest(BaseModel):
    interface: str

class StopTunnelResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[int] = None
    stopped_services: List[str] = []

class StartTunnelRequest(BaseModel):
    interface: str

class StartTunnelResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[int] = None
    started_services: List[str] = []

class TunnelStatsRequest(BaseModel):
    interface: str
    period: Optional[str] = "daily"  # "hourly", "daily", "weekly", "monthly"

class TunnelStatsResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[int] = None
    interface: str
    period: str
    current_usage: float
    traffic_limit: Optional[float] = None
    usage_percentage: Optional[float] = None
    is_traffic_limited: bool
    stats: List[Dict[str, Any]] = []

class AllTunnelsStatsResponse(BaseModel):
    success: bool
    message: str
    total_tunnels: int
    active_tunnels: int
    tunnels: List[Dict[str, Any]] = []

@router.get(
    "/tunnel_types", 
    response_model=TunnelTypeResponse, 
    summary="Get Tunnel Types",
    description="This API returns a list of all available tunnel types. Requires authentication.",
    responses={
        200: {"description": "Tunnel types list retrieved successfully"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Templates directory not found"},
        500: {"description": "Server error"}
    }
)
async def get_tunnel_types(current_user: User = Depends(get_current_user)) -> TunnelTypeResponse:
    """
    Get list of available tunnel types
    
    This endpoint requires a valid token and returns a list of all
    tunnel types available in the templates directory.
    """
    try:
        templates_dir = "d:\\Sublyne\\backend\\templates"
        
        if not os.path.exists(templates_dir) or not os.path.isdir(templates_dir):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, 
                detail="Templates directory not found"
            )
        
        tunnel_types = []
        for item in os.listdir(templates_dir):
            item_path = os.path.join(templates_dir, item)
            if os.path.isdir(item_path):
                tunnel_types.append(item)
        
        tunnel_types.sort()
        
        return TunnelTypeResponse(
            success=True,
            message="Tunnel types list retrieved successfully",
            tunnel_types=tunnel_types,
            count=len(tunnel_types)
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.post(
    "/add_tunnel_requirements",
    response_model=TunnelRequirementsResponse,
    summary="Get Tunnel Required Fields",
    description="This API reads the required fields from the corresponding JSON file based on tunnel type and server type.",
    responses={
        200: {"description": "Required fields retrieved successfully"},
        400: {"description": "Invalid input parameters"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Requested file not found"},
        500: {"description": "Server error"}
    }
)
async def add_tunnel_requirements(
    request: TunnelRequirementsRequest,
    current_user: User = Depends(get_current_user)
) -> TunnelRequirementsResponse:
    """
    Get required fields for tunnel creation
    
    This endpoint reads the appropriate JSON file from the templates directory
    based on tunnel_type and server_type, and returns the required fields.
    
    Args:
        tunnel_type: Type of tunnel (e.g., gre, vxlan4, etc.)
        server_type: Server type (origin or dest)
    """
    try:
        if request.server_type not in ["origin", "dest"]:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="server_type must be 'origin' or 'dest'"
            )
        
        templates_dir = "d:\\Sublyne\\backend\\templates"
        tunnel_dir = os.path.join(templates_dir, request.tunnel_type)
        
        if not os.path.exists(tunnel_dir) or not os.path.isdir(tunnel_dir):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel type '{request.tunnel_type}' not found"
            )
        
        filename = f"fields.ui.{request.server_type}.json"
        file_path = os.path.join(tunnel_dir, filename)
        
        if not os.path.exists(file_path):
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"File '{filename}' not found for tunnel '{request.tunnel_type}'"
            )
        
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                json_data = json.load(file)
        except json.JSONDecodeError:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"File '{filename}' does not have valid JSON format"
            )
        except Exception as e:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Error reading file: {str(e)}"
            )
        
        fields = json_data.get("fields", [])
        
        return TunnelRequirementsResponse(
            success=True,
            message=f"Required fields for tunnel '{request.tunnel_type}' and server '{request.server_type}' retrieved successfully",
            tunnel_type=request.tunnel_type,
            server_type=request.server_type,
            fields=fields
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.post(
    "/add_tunnel",
    response_model=AddTunnelResponse,
    summary="Add new tunnel",
    description="Create and configure a new tunnel with traffic monitoring"
)
async def add_tunnel(
    request: AddTunnelRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
):
        try:
            # Convert request to dict and remove unset values
            request_dict = request.dict(exclude_unset=True)
            
            # Validate tunnel_type and server_type
            tunnel_type = request_dict.get('tunnel_type')
            server_type = request_dict.get('server_type')
            
            if not tunnel_type or not server_type:
                raise HTTPException(status_code=400, detail="tunnel_type and server_type are required")
            
            if server_type not in ['origin', 'dest']:
                raise HTTPException(status_code=400, detail="server_type must be 'origin' or 'dest'")
            
            # Check if tunnel number already exists
            tunnel_number = request_dict.get('number')
            if tunnel_number:
                existing_tunnel = db.query(Tunnel).filter(Tunnel.number == tunnel_number).first()
                if existing_tunnel:
                    raise HTTPException(status_code=400, detail=f"Tunnel with number {tunnel_number} already exists")
            
            # Load and validate against template
            template_file = f"fields.ui.{server_type}.json"
            template_path = os.path.join("d:\\Sublyne\\backend\\templates", tunnel_type, template_file)
            
            if not os.path.exists(template_path):
                raise HTTPException(status_code=404, detail=f"Template not found for tunnel_type: {tunnel_type}")
            
            with open(template_path, 'r') as f:
                template_data = json.load(f)
            
            # Validate fields against template
            provided_fields = set(request_dict.keys())
            provided_fields.discard('tunnel_type')  # Remove tunnel_type as it's used for template selection
            
            required_fields = set()
            valid_fields = set()
            field_constraints = {}
            
            for field in template_data.get('fields', []):
                field_name = field.get('name')
                if field_name:
                    valid_fields.add(field_name)
                    if field.get('required', False):
                        required_fields.add(field_name)
                    field_constraints[field_name] = field.get('constraints', {})
            
            # Check for missing required fields
            missing_fields = required_fields - provided_fields
            if missing_fields:
                raise HTTPException(
                    status_code=400, 
                    detail=f"Validation failed: Missing required fields: {', '.join(missing_fields)}"
                )
            
            # Check for invalid field values
            invalid_fields = []
            for field_name, value in request_dict.items():
                if field_name in field_constraints:
                    constraints = field_constraints[field_name]
                    
                    # Check string length constraints
                    if isinstance(value, str):
                        if 'minLength' in constraints and len(value) < constraints['minLength']:
                            invalid_fields.append(f"{field_name}: minimum length {constraints['minLength']}")
                        if 'maxLength' in constraints and len(value) > constraints['maxLength']:
                            invalid_fields.append(f"{field_name}: maximum length {constraints['maxLength']}")
                    
                    # Check numeric constraints
                    if constraints.get('numeric') and not str(value).isdigit():
                        invalid_fields.append(f"{field_name}: must be numeric")
            
            # Check for unknown fields
            unknown_fields = provided_fields - valid_fields
            if unknown_fields:
                invalid_fields.append(f"Unknown fields: {', '.join(unknown_fields)}")
            
            if invalid_fields:
                raise HTTPException(
                    status_code=400,
                    detail=f"Validation failed: {'; '.join(invalid_fields)}"
                )
            
            # Generate private IPs
            tunnel_manager = TunnelManager(db)
            origin_private_ip, dest_private_ip = tunnel_manager.generate_private_ips(tunnel_number)
            
            # Create tunnel record
            tunnel_data = {
                'number': tunnel_number,
                'interface': request_dict.get('interface'),
                'tunnel_type': tunnel_type,
                'server_type': server_type,
                'ip_origin': request_dict.get('ip_origin'),
                'ip_dest': request_dict.get('ip_dest'),
                'tun_port': request_dict.get('tun_port'),
                'key': request_dict.get('key'),
                'origin_ports': request_dict.get('origin_ports'),
                'dest_ports': request_dict.get('dest_ports'),
                'forward_method': request_dict.get('forward_method', 'gost'),
                'traffic_limit': request_dict.get('traffic_limit'),
                'origin_private_ip': origin_private_ip,
                'dest_private_ip': dest_private_ip,
                'traffic_usage': 0.0,
                'is_active': True,
                'is_traffic_limited': False
            }
            
            tunnel = Tunnel(**tunnel_data)
            # random_phrase will be automatically generated in __init__ or before_insert event
            db.add(tunnel)
            db.commit()
            db.refresh(tunnel)
            
            # Create and start tunnel service
            if not tunnel_manager.create_tunnel_service(tunnel):
                db.delete(tunnel)
                db.commit()
                raise HTTPException(status_code=500, detail="Failed to create tunnel service")
            
            # Create and start gost service (for origin servers)
            if server_type == "origin":
                if not tunnel_manager.create_gost_service(tunnel):
                    tunnel_manager.stop_tunnel(tunnel)
                    db.delete(tunnel)
                    db.commit()
                    raise HTTPException(status_code=500, detail="Failed to create gost service")
                
                # Setup traffic monitoring
                if tunnel.origin_ports:
                    from app.utils.traffic_monitor import traffic_monitor
                    traffic_monitor.setup_iptables_rules(tunnel.origin_ports)
                    traffic_monitor.start_monitoring()
            
            # Update tunnel with service names
            db.commit()
            
            return {
                "status": "success",
                "message": "Tunnel created and started successfully",
                "tunnel": {
                    "id": tunnel.id,
                    "number": tunnel.number,
                    "tunnel_type": tunnel.tunnel_type,
                    "server_type": tunnel.server_type,
                    "origin_private_ip": tunnel.origin_private_ip,
                    "dest_private_ip": tunnel.dest_private_ip,
                    "service_name": tunnel.service_name,
                    "gost_service_name": tunnel.gost_service_name,
                    "is_active": tunnel.is_active
                }
            }
            
        except HTTPException:
            raise
        except Exception as e:
            logger.error(f"Error creating tunnel: {e}")
            raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@router.put(
    "/edit_tunnel",
    response_model=EditTunnelResponse,
    summary="Edit tunnel traffic limit",
    description="Update traffic limit for an existing tunnel identified by interface",
    responses={
        200: {"description": "Tunnel traffic limit updated successfully"},
        400: {"description": "Invalid input parameters"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Tunnel not found"},
        500: {"description": "Server error"}
    }
)
async def edit_tunnel(
    request: EditTunnelRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> EditTunnelResponse:
    """
    Edit tunnel traffic limit
    
    This endpoint updates the traffic limit for an existing tunnel
    identified by the interface parameter. If the tunnel was stopped
    due to traffic limit and the new limit is higher than current usage,
    the tunnel will be restarted automatically.
    
    Args:
        interface: Network interface of the tunnel to edit
        traffic_limit: New traffic limit in GB
    """
    try:
        # Validate input parameters
        if not request.interface or not request.interface.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Interface parameter is required and cannot be empty"
            )
        
        if request.traffic_limit <= 0:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Traffic limit must be greater than 0"
            )
        
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == request.interface.strip()).first()
        
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{request.interface}' not found"
            )
        
        # Store old traffic limit for response
        old_traffic_limit = tunnel.traffic_limit
        tunnel_restarted = False
        
        # Check if tunnel needs to be restarted
        # If tunnel was stopped due to traffic limit and new limit is higher than current usage
        should_restart = (
            tunnel.is_traffic_limited and 
            not tunnel.is_active and 
            tunnel.traffic_usage and 
            request.traffic_limit > tunnel.traffic_usage
        )
        
        # Update traffic limit
        tunnel.traffic_limit = request.traffic_limit
        
        # Reset traffic limitation status if new limit is higher than current usage
        if tunnel.traffic_usage and request.traffic_limit > tunnel.traffic_usage:
            tunnel.is_traffic_limited = False
            
            # Restart tunnel if it was stopped due to traffic limit
            if should_restart:
                tunnel_manager = TunnelManager(db)
                if tunnel_manager.start_tunnel(tunnel):
                    tunnel_restarted = True
                    
                    # Setup traffic monitoring for origin servers
                    if tunnel.server_type == "origin" and tunnel.origin_ports:
                        from app.utils.traffic_monitor import traffic_monitor
                        traffic_monitor.setup_iptables_rules(tunnel.origin_ports)
                        traffic_monitor.start_monitoring()
                else:
                    # If restart failed, log error but don't fail the API call
                    logger.error(f"Failed to restart tunnel {tunnel.id} after traffic limit increase")
        
        # Update timestamp
        tunnel.updated_at = datetime.utcnow()
        
        # Commit changes to database
        db.commit()
        db.refresh(tunnel)
        
        message = f"Traffic limit for tunnel with interface '{request.interface}' updated successfully"
        if tunnel_restarted:
            message += " and tunnel has been restarted"
        
        return EditTunnelResponse(
            success=True,
            message=message,
            tunnel_id=tunnel.id,
            old_traffic_limit=old_traffic_limit,
            new_traffic_limit=tunnel.traffic_limit,
            tunnel_restarted=tunnel_restarted
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )


@router.delete(
    "/delete_tunnel",
    response_model=DeleteTunnelResponse,
    summary="Delete tunnel completely",
    description="Completely delete a tunnel including services, files and database record",
    responses={
        200: {"description": "Tunnel deleted successfully"},
        400: {"description": "Invalid input parameters"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Tunnel not found"},
        500: {"description": "Server error"}
    }
)
async def delete_tunnel(
    request: DeleteTunnelRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> DeleteTunnelResponse:
    """
    Delete tunnel completely
    
    This endpoint completely removes a tunnel including:
    - Stopping and disabling systemd services
    - Removing service files
    - Running delete script for cleanup
    - Removing iptables rules
    - Deleting database record
    
    Args:
        interface: Network interface of the tunnel to delete
    """
    try:
        # Validate input parameters
        if not request.interface or not request.interface.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Interface parameter is required and cannot be empty"
            )
        
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == request.interface.strip()).first()
        
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{request.interface}' not found"
            )
        
        # Store tunnel info for response
        tunnel_id = tunnel.id
        deleted_services = []
        
        if tunnel.service_name:
            deleted_services.append(tunnel.service_name)
        if tunnel.gost_service_name:
            deleted_services.append(tunnel.gost_service_name)
        
        # Delete tunnel using TunnelManager
        tunnel_manager = TunnelManager(db)
        
        if not tunnel_manager.delete_tunnel(tunnel):
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to delete tunnel services and cleanup"
            )
        
        # Delete tunnel record from database
        db.delete(tunnel)
        db.commit()
        
        return DeleteTunnelResponse(
            success=True,
            message=f"Tunnel with interface '{request.interface}' deleted successfully",
            tunnel_id=tunnel_id,
            deleted_services=deleted_services
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Error deleting tunnel: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.post(
    "/stop_tunnel",
    response_model=StopTunnelResponse,
    summary="Stop Tunnel",
    description="Stop and disable tunnel and GOST services for a specific tunnel interface. Requires authentication.",
    responses={
        200: {"description": "Tunnel stopped successfully"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Tunnel not found"},
        500: {"description": "Server error"}
    }
)
async def stop_tunnel(
    request: StopTunnelRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> StopTunnelResponse:
    """
    Stop tunnel and GOST services
    
    This endpoint stops and disables both tunnel and GOST services
    for the specified tunnel interface.
    """
    try:
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == request.interface).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{request.interface}' not found"
            )
        
        tunnel_id = tunnel.id
        stopped_services = []
        
        # Initialize tunnel manager
        tunnel_manager = TunnelManager()
        
        # Stop tunnel service
        try:
            tunnel_manager.stop_tunnel(tunnel)
            stopped_services.append(tunnel.service_name)
            logger.info(f"Tunnel service {tunnel.service_name} stopped successfully")
        except Exception as e:
            logger.error(f"Error stopping tunnel service: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to stop tunnel service: {str(e)}"
            )
        
        # Stop GOST service
        try:
            # Stop GOST service using systemctl
            import subprocess
            subprocess.run(["systemctl", "stop", tunnel.gost_service_name], check=True)
            subprocess.run(["systemctl", "disable", tunnel.gost_service_name], check=True)
            stopped_services.append(tunnel.gost_service_name)
            logger.info(f"GOST service {tunnel.gost_service_name} stopped and disabled successfully")
        except subprocess.CalledProcessError as e:
            logger.error(f"Error stopping GOST service: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to stop GOST service: {str(e)}"
            )
        
        # Update tunnel status in database
        tunnel.is_active = False
        tunnel.updated_at = datetime.utcnow()
        db.commit()
        
        logger.info(f"Tunnel {request.interface} stopped successfully")
        
        return StopTunnelResponse(
            success=True,
            message=f"Tunnel '{request.interface}' stopped successfully",
            tunnel_id=tunnel_id,
            stopped_services=stopped_services
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Error stopping tunnel: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.post(
    "/start_tunnel",
    response_model=StartTunnelResponse,
    summary="Start Tunnel",
    description="Start and enable tunnel and GOST services for a specific tunnel interface. Requires authentication.",
    responses={
        200: {"description": "Tunnel started successfully"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Tunnel not found"},
        500: {"description": "Server error"}
    }
)
async def start_tunnel(
    request: StartTunnelRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> StartTunnelResponse:
    """
    Start tunnel and GOST services
    
    This endpoint starts and enables both tunnel and GOST services
    for the specified tunnel interface.
    """
    try:
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == request.interface).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{request.interface}' not found"
            )
        
        tunnel_id = tunnel.id
        started_services = []
        
        # Initialize tunnel manager
        tunnel_manager = TunnelManager()
        
        # Start tunnel service
        try:
            tunnel_manager.start_tunnel(tunnel)
            started_services.append(tunnel.service_name)
            logger.info(f"Tunnel service {tunnel.service_name} started successfully")
        except Exception as e:
            logger.error(f"Error starting tunnel service: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to start tunnel service: {str(e)}"
            )
        
        # Start GOST service
        try:
            # Start GOST service using systemctl
            import subprocess
            subprocess.run(["systemctl", "enable", tunnel.gost_service_name], check=True)
            subprocess.run(["systemctl", "start", tunnel.gost_service_name], check=True)
            started_services.append(tunnel.gost_service_name)
            logger.info(f"GOST service {tunnel.gost_service_name} enabled and started successfully")
        except subprocess.CalledProcessError as e:
            logger.error(f"Error starting GOST service: {e}")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to start GOST service: {str(e)}"
            )
        
        # Set up iptables rules and traffic monitoring for origin servers
        if tunnel.server_type == "origin" and tunnel.origin_ports:
            try:
                # Set up iptables rules for traffic monitoring
                import subprocess
                ports = tunnel.origin_ports.split(",")
                for port in ports:
                    port = port.strip()
                    if port:
                        # Add iptables rule for incoming traffic
                        subprocess.run([
                            "iptables", "-I", "INPUT", "-p", "tcp", "--dport", port, 
                            "-j", "ACCEPT", "-m", "comment", "--comment", f"tunnel_{tunnel.interface}"
                        ], check=True)
                        
                        # Add iptables rule for outgoing traffic
                        subprocess.run([
                            "iptables", "-I", "OUTPUT", "-p", "tcp", "--sport", port, 
                            "-j", "ACCEPT", "-m", "comment", "--comment", f"tunnel_{tunnel.interface}"
                        ], check=True)
                
                logger.info(f"Iptables rules set up for tunnel {tunnel.interface}")
                
                # Start traffic monitoring
                from app.utils.traffic_monitor import start_traffic_monitoring
                start_traffic_monitoring(tunnel.interface)
                logger.info(f"Traffic monitoring started for tunnel {tunnel.interface}")
                
            except Exception as e:
                logger.error(f"Error setting up iptables rules or traffic monitoring: {e}")
                # Don't fail the entire operation for this
        
        # Update tunnel status in database
        tunnel.is_active = True
        tunnel.updated_at = datetime.utcnow()
        db.commit()
        
        logger.info(f"Tunnel {request.interface} started successfully")
        
        return StartTunnelResponse(
            success=True,
            message=f"Tunnel '{request.interface}' started successfully",
            tunnel_id=tunnel_id,
            started_services=started_services
        )
        
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        logger.error(f"Error starting tunnel: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )


@router.get(
    "/tunnel_stats/{random_phrase}",
    response_model=TunnelStatsResponse,
    summary="Get Tunnel Traffic Statistics",
    description="Get detailed traffic statistics for a specific tunnel using random phrase. Requires authentication.",
    responses={
        200: {"description": "Tunnel statistics retrieved successfully"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        404: {"description": "Tunnel not found"},
        500: {"description": "Server error"}
    }
)
async def get_tunnel_stats(
    random_phrase: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> TunnelStatsResponse:
    """
    Get traffic statistics for a specific tunnel using random phrase
    
    This endpoint returns detailed traffic statistics including current usage,
    traffic limit, usage percentage, and historical data.
    """
    try:
        # Find tunnel by random_phrase
        tunnel = db.query(Tunnel).filter(Tunnel.random_phrase == random_phrase).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with random phrase '{random_phrase}' not found"
            )
        
        # Calculate usage percentage
        usage_percentage = None
        if tunnel.traffic_limit and tunnel.traffic_limit > 0:
            usage_percentage = (tunnel.traffic_usage / tunnel.traffic_limit) * 100
        
        # Get historical stats from TrafficStats table (daily stats for last 30 days)
        from app.models.traffic_stats import TrafficStats
        from sqlalchemy import and_, func
        from datetime import datetime, timedelta
        
        # Get daily stats for last 30 days
        now = datetime.utcnow()
        start_date = now - timedelta(days=30)
        stats_query = db.query(TrafficStats).filter(
            and_(
                TrafficStats.tunnel_id == tunnel.id,
                TrafficStats.recorded_at >= start_date,
                TrafficStats.stat_type == "daily"
            )
        ).order_by(TrafficStats.recorded_at.desc())
        
        stats_records = stats_query.all()
        
        # Format stats data
        stats_data = []
        for stat in stats_records:
            stats_data.append({
                "date": stat.recorded_at.isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.bytes_in + stat.bytes_out,
                "packets_in": stat.packets_in,
                "packets_out": stat.packets_out,
                "total_packets": stat.packets_in + stat.packets_out
            })
        
        logger.info(f"Retrieved {len(stats_data)} statistics records for tunnel {tunnel.interface}")
        
        return TunnelStatsResponse(
            success=True,
            message=f"Statistics for tunnel '{tunnel.interface}' retrieved successfully",
            tunnel_id=tunnel.id,
            interface=tunnel.interface,
            period="daily",
            current_usage=tunnel.traffic_usage or 0.0,
            traffic_limit=tunnel.traffic_limit,
            usage_percentage=usage_percentage,
            is_traffic_limited=tunnel.is_traffic_limited,
            stats=stats_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving tunnel statistics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/all_tunnels_stats",
    response_model=AllTunnelsStatsResponse,
    summary="Get All Tunnels Statistics",
    description="Get overview statistics for all tunnels. Requires authentication.",
    responses={
        200: {"description": "All tunnels statistics retrieved successfully"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        500: {"description": "Server error"}
    }
)
async def get_all_tunnels_stats(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> AllTunnelsStatsResponse:
    """
    Get overview statistics for all tunnels
    
    This endpoint returns a summary of all tunnels including their current
    usage, limits, and status.
    """
    try:
        # Get all tunnels
        tunnels = db.query(Tunnel).all()
        
        total_tunnels = len(tunnels)
        active_tunnels = len([t for t in tunnels if t.is_active])
        
        tunnels_data = []
        for tunnel in tunnels:
            # Calculate usage percentage
            usage_percentage = None
            if tunnel.traffic_limit and tunnel.traffic_limit > 0:
                usage_percentage = (tunnel.traffic_usage / tunnel.traffic_limit) * 100
            
            tunnels_data.append({
                "id": tunnel.id,
                "interface": tunnel.interface,
                "tunnel_type": tunnel.tunnel_type,
                "server_type": tunnel.server_type,
                "is_active": tunnel.is_active,
                "current_usage": tunnel.traffic_usage or 0.0,
                "traffic_limit": tunnel.traffic_limit,
                "usage_percentage": usage_percentage,
                "is_traffic_limited": tunnel.is_traffic_limited,
                "created_at": tunnel.created_at.isoformat() if tunnel.created_at else None,
                "last_traffic_check": tunnel.last_traffic_check.isoformat() if tunnel.last_traffic_check else None
            })
        
        logger.info(f"Retrieved statistics for {total_tunnels} tunnels")
        
        return AllTunnelsStatsResponse(
            success=True,
            message=f"Statistics for all tunnels retrieved successfully",
            total_tunnels=total_tunnels,
            active_tunnels=active_tunnels,
            tunnels=tunnels_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving all tunnels statistics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

# API های آمار حذف شدند - این APIها باید فقط در stats.py باشند