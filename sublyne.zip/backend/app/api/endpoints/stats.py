import os
import json
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_, func
from app.core.security import get_current_user
from app.models.user import User
from app.models.tunnel import Tunnel
from app.models.traffic_stats import TrafficStats
from app.db.init_db import get_database
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter()

class TunnelStatsRequest(BaseModel):
    interface: str
    period: Optional[str] = "daily"  # "hourly", "daily", "weekly", "monthly"

class TunnelStatsResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: Optional[int] = None
    interface: str
    period: str
    current_usage: float
    traffic_limit: Optional[float] = None
    usage_percentage: Optional[float] = None
    is_traffic_limited: bool
    stats: List[Dict[str, Any]] = []

class AllTunnelsStatsResponse(BaseModel):
    success: bool
    message: str
    total_tunnels: int
    tunnels: List[Dict[str, Any]] = []  # حذف active_tunnels

class HourlyTrafficResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: int
    hours: int
    stats: List[Dict[str, Any]] = []

class DailyTrafficResponse(BaseModel):
    success: bool
    message: str
    tunnel_id: int
    days: int
    stats: List[Dict[str, Any]] = []

class TunnelStatsResponse(BaseModel):
    success: bool
    message: str
    interface: str
    status: str
    connection: Optional[float] = None
    origin_ip: Optional[str] = None
    traffic_limit: Optional[float] = None
    traffic_usage: float
    cpu_usage: float
    ram_usage: float
    today_traffic: float  # Today's traffic in GB

# API زیر کاملاً حذف شد:
# @router.get("/tunnel_stats/{interface}", ...)
# async def get_tunnel_stats(interface: str, period: str = Query("daily", ...), ...)

async def get_tunnel_stats(
    interface: str,
    period: str = Query("daily", description="Period type: hourly, daily, weekly, monthly"),
    db: Session = Depends(get_database)
) -> TunnelStatsResponse:
    """
    Get traffic statistics for a specific tunnel
    
    This endpoint returns detailed traffic statistics including current usage,
    traffic limit, usage percentage, and historical data.
    """
    try:
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == interface).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{interface}' not found"
            )
        
        # Calculate usage percentage
        usage_percentage = None
        if tunnel.traffic_limit and tunnel.traffic_limit > 0:
            usage_percentage = (tunnel.traffic_usage / tunnel.traffic_limit) * 100
        
        # Determine date range based on period
        now = datetime.utcnow()
        if period == "hourly":
            start_date = now - timedelta(hours=24)
            stats_query = db.query(TrafficStats).filter(
                and_(
                    TrafficStats.tunnel_id == tunnel.id,
                    TrafficStats.recorded_at >= start_date,
                    TrafficStats.stat_type == "hourly"
                )
            ).order_by(TrafficStats.recorded_at.desc())
        elif period == "daily":
            start_date = now - timedelta(days=30)
            stats_query = db.query(TrafficStats).filter(
                and_(
                    TrafficStats.tunnel_id == tunnel.id,
                    TrafficStats.recorded_at >= start_date,
                    TrafficStats.stat_type == "daily"
                )
            ).order_by(TrafficStats.recorded_at.desc())
        elif period == "weekly":
            start_date = now - timedelta(weeks=12)
            stats_query = db.query(TrafficStats).filter(
                and_(
                    TrafficStats.tunnel_id == tunnel.id,
                    TrafficStats.recorded_at >= start_date,
                    TrafficStats.stat_type == "daily"
                )
            ).order_by(TrafficStats.recorded_at.desc())
        elif period == "monthly":
            start_date = now - timedelta(days=365)
            stats_query = db.query(TrafficStats).filter(
                and_(
                    TrafficStats.tunnel_id == tunnel.id,
                    TrafficStats.recorded_at >= start_date,
                    TrafficStats.stat_type == "daily"
                )
            ).order_by(TrafficStats.recorded_at.desc())
        else:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid period. Must be one of: hourly, daily, weekly, monthly"
            )
        
        stats_records = stats_query.all()
        
        # Format stats data
        stats_data = []
        for stat in stats_records:
            stats_data.append({
                "date": stat.recorded_at.isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.bytes_in + stat.bytes_out,
                "total_gb": round((stat.bytes_in + stat.bytes_out) / (1024**3), 4),
                "packets_in": stat.packets_in,
                "packets_out": stat.packets_out,
                "total_packets": stat.packets_in + stat.packets_out
            })
        
        logger.info(f"Retrieved {len(stats_data)} statistics records for tunnel {interface}")
        
        return TunnelStatsResponse(
            success=True,
            message=f"Statistics for tunnel '{interface}' retrieved successfully",
            tunnel_id=tunnel.id,
            interface=interface,
            period=period,
            current_usage=tunnel.traffic_usage or 0.0,
            traffic_limit=tunnel.traffic_limit,
            usage_percentage=usage_percentage,
            is_traffic_limited=tunnel.is_traffic_limited,
            stats=stats_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving tunnel statistics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/tunnel_stats/{random_phrase}",
    response_model=TunnelStatsResponse,
    summary="Get Tunnel Traffic Statistics",
    description="Get detailed traffic statistics for a specific tunnel using random phrase. No authentication required.",
    responses={
        200: {"description": "Tunnel statistics retrieved successfully"},
        404: {"description": "Tunnel not found"},
        500: {"description": "Server error"}
    }
)
async def get_tunnel_stats(
    random_phrase: str,
    db: Session = Depends(get_database)
) -> TunnelStatsResponse:
    """
    Get traffic statistics for a specific tunnel using random phrase
    
    This endpoint returns detailed traffic statistics including current usage,
    traffic limit, usage percentage, and daily historical data for last 30 days.
    """
    try:
        # Find tunnel by random_phrase
        tunnel = db.query(Tunnel).filter(Tunnel.random_phrase == random_phrase).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with random phrase '{random_phrase}' not found"
            )
        
        # Calculate usage percentage
        usage_percentage = None
        if tunnel.traffic_limit and tunnel.traffic_limit > 0:
            usage_percentage = (tunnel.traffic_usage / tunnel.traffic_limit) * 100
        
        # Get daily stats for last 30 days
        now = datetime.utcnow()
        start_date = now - timedelta(days=30)
        stats_query = db.query(TrafficStats).filter(
            and_(
                TrafficStats.tunnel_id == tunnel.id,
                TrafficStats.recorded_at >= start_date,
                TrafficStats.stat_type == "daily"
            )
        ).order_by(TrafficStats.recorded_at.desc())
        
        stats_records = stats_query.all()
        
        # Format stats data
        stats_data = []
        for stat in stats_records:
            stats_data.append({
                "date": stat.recorded_at.isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.bytes_in + stat.bytes_out,
                "total_gb": round((stat.bytes_in + stat.bytes_out) / (1024**3), 4),
                "packets_in": stat.packets_in,
                "packets_out": stat.packets_out,
                "total_packets": stat.packets_in + stat.packets_out
            })
        
        logger.info(f"Retrieved {len(stats_data)} statistics records for tunnel {tunnel.interface}")
        
        return TunnelStatsResponse(
            success=True,
            message=f"Statistics for tunnel '{tunnel.interface}' retrieved successfully",
            tunnel_id=tunnel.id,
            interface=tunnel.interface,
            period="daily",
            current_usage=tunnel.traffic_usage or 0.0,
            traffic_limit=tunnel.traffic_limit,
            usage_percentage=usage_percentage,
            is_traffic_limited=tunnel.is_traffic_limited,
            stats=stats_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving tunnel statistics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/all_tunnels_stats",
    response_model=AllTunnelsStatsResponse,
    summary="Get All Tunnels Statistics",
    description="Get overview statistics for all tunnels. Requires authentication.",
    responses={
        200: {"description": "All tunnels statistics retrieved successfully"},
        401: {"description": "Unauthorized - Invalid or expired token"},
        500: {"description": "Server error"}
    }
)
async def get_all_tunnels_stats(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> AllTunnelsStatsResponse:
    """
    Get overview statistics for all tunnels
    
    This endpoint returns a list of all tunnels sorted by number,
    showing only number, interface, status and connection for each tunnel.
    """
    try:
        # Get all tunnels ordered by number
        tunnels = db.query(Tunnel).order_by(Tunnel.number).all()
        
        total_tunnels = len(tunnels)
        
        tunnels_data = []
        for tunnel in tunnels:
            tunnels_data.append({
                "number": tunnel.number,
                "interface": tunnel.interface,
                "status": tunnel.status or "unknown",
                "connection": tunnel.connection
            })
        
        logger.info(f"Retrieved statistics for {total_tunnels} tunnels")
        
        return AllTunnelsStatsResponse(
            success=True,
            message=f"Statistics for all tunnels retrieved successfully",
            total_tunnels=total_tunnels,
            tunnels=tunnels_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving all tunnels statistics: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/tunnel_traffic/{interface}/hourly",
    response_model=HourlyTrafficResponse,
    summary="Get Hourly Traffic Statistics",
    description="Get hourly traffic statistics for a specific tunnel interface. Requires authentication."
)
async def get_hourly_traffic(
    interface: str,
    hours: int = Query(24, description="Number of hours to retrieve (default: 24)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> HourlyTrafficResponse:
    """
    Get hourly traffic statistics for a tunnel by interface
    """
    try:
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == interface).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{interface}' not found"
            )
        
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=hours)
        
        # Get hourly stats
        hourly_stats = db.query(TrafficStats).filter(
            TrafficStats.tunnel_id == tunnel.id,
            TrafficStats.stat_type == 'hourly',
            TrafficStats.recorded_at >= start_time,
            TrafficStats.recorded_at <= end_time
        ).order_by(TrafficStats.recorded_at.desc()).all()
        
        # Format response
        stats_data = []
        for stat in hourly_stats:
            stats_data.append({
                "recorded_at": stat.recorded_at.isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.bytes_in + stat.bytes_out,
                "total_gb": round((stat.bytes_in + stat.bytes_out) / (1024**3), 4),
                "packets_in": stat.packets_in,
                "packets_out": stat.packets_out,
                "total_packets": stat.packets_in + stat.packets_out
            })
        
        return HourlyTrafficResponse(
            success=True,
            message=f"Hourly traffic statistics retrieved for tunnel '{interface}'",
            tunnel_id=tunnel.id,
            hours=hours,
            stats=stats_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving hourly traffic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/tunnel_traffic/{interface}/daily",
    response_model=DailyTrafficResponse,
    summary="Get Daily Traffic Statistics",
    description="Get daily traffic statistics for a specific tunnel interface. Requires authentication."
)
async def get_daily_traffic(
    interface: str,
    days: int = Query(30, description="Number of days to retrieve (default: 30)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> DailyTrafficResponse:
    """
    Get daily traffic statistics for a tunnel by interface
    """
    try:
        # Find tunnel by interface
        tunnel = db.query(Tunnel).filter(Tunnel.interface == interface).first()
        if not tunnel:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Tunnel with interface '{interface}' not found"
            )
        
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)
        
        # Get daily stats
        daily_stats = db.query(TrafficStats).filter(
            TrafficStats.tunnel_id == tunnel.id,
            TrafficStats.stat_type == 'daily',
            TrafficStats.recorded_at >= start_time,
            TrafficStats.recorded_at <= end_time
        ).order_by(TrafficStats.recorded_at.desc()).all()
        
        # Format response
        stats_data = []
        for stat in daily_stats:
            stats_data.append({
                "recorded_at": stat.recorded_at.isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.bytes_in + stat.bytes_out,
                "total_gb": round((stat.bytes_in + stat.bytes_out) / (1024**3), 4),
                "packets_in": stat.packets_in,
                "packets_out": stat.packets_out,
                "total_packets": stat.packets_in + stat.packets_out
            })
        
        return DailyTrafficResponse(
            success=True,
            message=f"Daily traffic statistics retrieved for tunnel '{interface}'",
            tunnel_id=tunnel.id,
            days=days,
            stats=stats_data
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error retrieving daily traffic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/project_traffic/hourly",
    response_model=HourlyTrafficResponse,
    summary="Get Project Hourly Traffic Statistics",
    description="Get hourly traffic statistics for the entire tunneling project. Requires authentication."
)
async def get_project_hourly_traffic(
    hours: int = Query(24, description="Number of hours to retrieve (default: 24)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> HourlyTrafficResponse:
    """
    Get hourly traffic statistics for the entire project
    """
    try:
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=hours)
        
        # Get hourly stats for all tunnels aggregated
        hourly_stats = db.query(
            TrafficStats.recorded_at,
            func.sum(TrafficStats.bytes_in).label('total_bytes_in'),
            func.sum(TrafficStats.bytes_out).label('total_bytes_out'),
            func.sum(TrafficStats.packets_in).label('total_packets_in'),
            func.sum(TrafficStats.packets_out).label('total_packets_out')
        ).filter(
            TrafficStats.stat_type == 'hourly',
            TrafficStats.recorded_at >= start_time,
            TrafficStats.recorded_at <= end_time
        ).group_by(TrafficStats.recorded_at).order_by(TrafficStats.recorded_at.desc()).all()
        
        # Format response
        stats_data = []
        for stat in hourly_stats:
            total_bytes = stat.total_bytes_in + stat.total_bytes_out
            stats_data.append({
                "recorded_at": stat.recorded_at.isoformat(),
                "bytes_in": stat.total_bytes_in,
                "bytes_out": stat.total_bytes_out,
                "total_bytes": total_bytes,
                "total_gb": round(total_bytes / (1024**3), 4),
                "packets_in": stat.total_packets_in,
                "packets_out": stat.total_packets_out,
                "total_packets": stat.total_packets_in + stat.total_packets_out
            })
        
        return HourlyTrafficResponse(
            success=True,
            message=f"Project hourly traffic statistics retrieved",
            tunnel_id=0,  # 0 indicates project-wide stats
            hours=hours,
            stats=stats_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving project hourly traffic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )

@router.get(
    "/project_traffic/daily",
    response_model=DailyTrafficResponse,
    summary="Get Project Daily Traffic Statistics",
    description="Get daily traffic statistics for the entire tunneling project. Requires authentication."
)
async def get_project_daily_traffic(
    days: int = Query(30, description="Number of days to retrieve (default: 30)"),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_database)
) -> DailyTrafficResponse:
    """
    Get daily traffic statistics for the entire project
    """
    try:
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)
        
        # Get daily stats for all tunnels aggregated
        daily_stats = db.query(
            TrafficStats.recorded_at,
            func.sum(TrafficStats.bytes_in).label('total_bytes_in'),
            func.sum(TrafficStats.bytes_out).label('total_bytes_out'),
            func.sum(TrafficStats.packets_in).label('total_packets_in'),
            func.sum(TrafficStats.packets_out).label('total_packets_out')
        ).filter(
            TrafficStats.stat_type == 'daily',
            TrafficStats.recorded_at >= start_time,
            TrafficStats.recorded_at <= end_time
        ).group_by(TrafficStats.recorded_at).order_by(TrafficStats.recorded_at.desc()).all()
        
        # Format response
        stats_data = []
        for stat in daily_stats:
            total_bytes = stat.total_bytes_in + stat.total_bytes_out
            stats_data.append({
                "recorded_at": stat.recorded_at.isoformat(),
                "bytes_in": stat.total_bytes_in,
                "bytes_out": stat.total_bytes_out,
                "total_bytes": total_bytes,
                "total_gb": round(total_bytes / (1024**3), 4),
                "packets_in": stat.total_packets_in,
                "packets_out": stat.total_packets_out,
                "total_packets": stat.total_packets_in + stat.total_packets_out
            })
        
        return DailyTrafficResponse(
            success=True,
            message=f"Project daily traffic statistics retrieved",
            tunnel_id=0,  # 0 indicates project-wide stats
            days=days,
            stats=stats_data
        )
        
    except Exception as e:
        logger.error(f"Error retrieving project daily traffic: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Server error: {str(e)}"
        )