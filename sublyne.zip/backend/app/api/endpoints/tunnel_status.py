from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
from app.db.init_db import get_db
from app.models.tunnel import Tunnel
from app.models.traffic_stats import TrafficStats
from app.core.security import get_current_user
from app.models.user import User
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

@router.get("/tunnels/{tunnel_id}/traffic/hourly")
def get_hourly_traffic(
    tunnel_id: int,
    hours: int = Query(24, description="Number of hours to retrieve (default: 24)"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get hourly traffic statistics for a tunnel"""
    try:
        # Check if tunnel exists
        tunnel = db.query(Tunnel).filter(Tunnel.id == tunnel_id).first()
        if not tunnel:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=hours)
        
        # Get hourly stats
        hourly_stats = db.query(TrafficStats).filter(
            TrafficStats.tunnel_id == tunnel_id,
            TrafficStats.period_type == 'hourly',
            TrafficStats.period_start >= start_time,
            TrafficStats.period_start <= end_time
        ).order_by(TrafficStats.period_start.desc()).all()
        
        # Format response
        stats_data = []
        for stat in hourly_stats:
            stats_data.append({
                "period_start": stat.period_start.isoformat(),
                "period_end": stat.period_end.isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.total_bytes,
                "total_gb": round(stat.total_bytes / (1024**3), 4)
            })
        
        return {
            "tunnel_id": tunnel_id,
            "tunnel_number": tunnel.number,
            "period_type": "hourly",
            "hours_requested": hours,
            "stats_count": len(stats_data),
            "stats": stats_data
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting hourly traffic: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/tunnels/{tunnel_id}/traffic/daily")
def get_daily_traffic(
    tunnel_id: int,
    days: int = Query(30, description="Number of days to retrieve (default: 30)"),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get daily traffic statistics for a tunnel"""
    try:
        # Check if tunnel exists
        tunnel = db.query(Tunnel).filter(Tunnel.id == tunnel_id).first()
        if not tunnel:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        
        # Calculate time range
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)
        
        # Get daily stats
        daily_stats = db.query(TrafficStats).filter(
            TrafficStats.tunnel_id == tunnel_id,
            TrafficStats.period_type == 'daily',
            TrafficStats.period_start >= start_time,
            TrafficStats.period_start <= end_time
        ).order_by(TrafficStats.period_start.desc()).all()
        
        # Format response
        stats_data = []
        for stat in daily_stats:
            stats_data.append({
                "date": stat.period_start.date().isoformat(),
                "bytes_in": stat.bytes_in,
                "bytes_out": stat.bytes_out,
                "total_bytes": stat.total_bytes,
                "total_gb": round(stat.total_bytes / (1024**3), 4)
            })
        
        return {
            "tunnel_id": tunnel_id,
            "tunnel_number": tunnel.number,
            "period_type": "daily",
            "days_requested": days,
            "stats_count": len(stats_data),
            "stats": stats_data
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting daily traffic: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/tunnels/{tunnel_id}/status")
def get_tunnel_status(
    tunnel_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get current tunnel status and recent traffic"""
    try:
        # Get tunnel
        tunnel = db.query(Tunnel).filter(Tunnel.id == tunnel_id).first()
        if not tunnel:
            raise HTTPException(status_code=404, detail="Tunnel not found")
        
        # Get latest hourly stat
        latest_hourly = db.query(TrafficStats).filter(
            TrafficStats.tunnel_id == tunnel_id,
            TrafficStats.period_type == 'hourly'
        ).order_by(TrafficStats.period_start.desc()).first()
        
        # Get today's daily stat
        today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        today_daily = db.query(TrafficStats).filter(
            TrafficStats.tunnel_id == tunnel_id,
            TrafficStats.period_type == 'daily',
            TrafficStats.period_start == today
        ).first()
        
        return {
            "tunnel_id": tunnel.id,
            "tunnel_number": tunnel.number,
            "tunnel_type": tunnel.tunnel_type,
            "server_type": tunnel.server_type,
            "is_active": tunnel.is_active,
            "is_traffic_limited": tunnel.is_traffic_limited,
            "traffic_limit_gb": tunnel.traffic_limit,
            "current_usage_gb": tunnel.traffic_usage,
            "last_traffic_check": tunnel.last_traffic_check.isoformat() if tunnel.last_traffic_check else None,
            "latest_hourly_traffic": {
                "period_start": latest_hourly.period_start.isoformat() if latest_hourly else None,
                "total_gb": round(latest_hourly.total_bytes / (1024**3), 4) if latest_hourly else 0
            } if latest_hourly else None,
            "today_traffic": {
                "date": today.date().isoformat(),
                "total_gb": round(today_daily.total_bytes / (1024**3), 4) if today_daily else 0
            } if today_daily else None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting tunnel status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")

@router.get("/tunnels/overview")
def get_tunnels_overview(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get overview of all tunnels with their current status"""
    try:
        tunnels = db.query(Tunnel).all()
        
        overview_data = []
        for tunnel in tunnels:
            # Get today's traffic
            today = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            today_traffic = db.query(TrafficStats).filter(
                TrafficStats.tunnel_id == tunnel.id,
                TrafficStats.period_type == 'daily',
                TrafficStats.period_start == today
            ).first()
            
            overview_data.append({
                "tunnel_id": tunnel.id,
                "tunnel_number": tunnel.number,
                "tunnel_type": tunnel.tunnel_type,
                "server_type": tunnel.server_type,
                "is_active": tunnel.is_active,
                "is_traffic_limited": tunnel.is_traffic_limited,
                "traffic_limit_gb": tunnel.traffic_limit,
                "current_usage_gb": tunnel.traffic_usage,
                "today_traffic_gb": round(today_traffic.total_bytes / (1024**3), 4) if today_traffic else 0,
                "usage_percentage": round((tunnel.traffic_usage / tunnel.traffic_limit) * 100, 2) if tunnel.traffic_limit else 0
            })
        
        return {
            "total_tunnels": len(tunnels),
            "active_tunnels": len([t for t in tunnels if t.is_active]),
            "limited_tunnels": len([t for t in tunnels if t.is_traffic_limited]),
            "tunnels": overview_data
        }
        
    except Exception as e:
        logger.error(f"Error getting tunnels overview: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")