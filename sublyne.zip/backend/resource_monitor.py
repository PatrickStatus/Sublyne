import asyncio
import psutil
import logging
from datetime import datetime
from sqlalchemy.orm import Session
from app.db.init_db import get_database
from app.models.tunnel import Tunnel

logger = logging.getLogger(__name__)

class ResourceMonitor:
    def __init__(self):
        self.running = False
    
    def get_process_by_name(self, process_name: str):
        """Find process by name"""
        for proc in psutil.process_iter(['pid', 'name', 'cmdline']):
            try:
                if process_name.lower() in proc.info['name'].lower():
                    return proc
                # Also check command line for gost processes
                if proc.info['cmdline']:
                    cmdline = ' '.join(proc.info['cmdline'])
                    if process_name in cmdline:
                        return proc
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return None
    
    async def check_tunnel_resources(self):
        """Check CPU and RAM usage for all tunnel services"""
        db = next(get_database())
        try:
            # Get all active tunnels with gost service names
            tunnels = db.query(Tunnel).filter(
                Tunnel.is_active == True,
                Tunnel.gost_service_name.isnot(None)
            ).all()
            
            for tunnel in tunnels:
                try:
                    # Find gost process for this tunnel
                    process = self.get_process_by_name(tunnel.gost_service_name)
                    
                    if process:
                        # Get CPU and memory usage
                        cpu_percent = process.cpu_percent(interval=1)
                        memory_info = process.memory_info()
                        ram_mb = memory_info.rss / (1024 * 1024)  # Convert to MB
                        
                        # Update tunnel resource usage
                        tunnel.cpu_usage = round(cpu_percent, 2)
                        tunnel.ram_usage = round(ram_mb, 2)
                        tunnel.status = "running"
                        
                        logger.info(f"Tunnel {tunnel.interface}: CPU {cpu_percent}%, RAM {ram_mb:.2f}MB")
                    else:
                        # Process not found
                        tunnel.cpu_usage = 0.0
                        tunnel.ram_usage = 0.0
                        tunnel.status = "stopped"
                        
                        logger.warning(f"Gost process not found for tunnel {tunnel.interface}")
                    
                    tunnel.last_resource_check = datetime.utcnow()
                    
                except Exception as e:
                    logger.error(f"Error checking resources for tunnel {tunnel.interface}: {e}")
                    tunnel.status = "error"
                    tunnel.last_resource_check = datetime.utcnow()
            
            db.commit()
            
        except Exception as e:
            logger.error(f"Error in resource monitoring: {e}")
            db.rollback()
        finally:
            db.close()
    
    async def start_monitoring(self):
        """Start resource monitoring loop"""
        self.running = True
        logger.info("Resource monitoring started")
        
        while self.running:
            try:
                await self.check_tunnel_resources()
                await asyncio.sleep(60)  # Check every 60 seconds
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(60)
    
    def stop_monitoring(self):
        """Stop resource monitoring"""
        self.running = False
        logger.info("Resource monitoring stopped")

# Global monitor instance
resource_monitor = ResourceMonitor()

if __name__ == "__main__":
    asyncio.run(resource_monitor.start_monitoring())