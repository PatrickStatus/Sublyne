#!/bin/bash

# Sublyne Traffic Monitor Startup Script
# This script restores iptables rules and starts traffic monitoring after reboot

echo "Starting Sublyne Traffic Monitor..."

# Change to backend directory
cd "$(dirname "$0")"

# Set Python path
export PYTHONPATH="$PWD:$PYTHONPATH"

# Restore iptables rules and start monitoring
python3 -c "
import sys
sys.path.insert(0, '.')

from app.utils.traffic_monitor import traffic_monitor
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

try:
    # Restore iptables rules for all active tunnels
    traffic_monitor.restore_iptables_rules()
    
    # Start traffic monitoring
    traffic_monitor.start_monitoring()
    
    logger.info('Sublyne Traffic Monitor started successfully')
    
except Exception as e:
    logger.error(f'Failed to start Sublyne Traffic Monitor: {e}')
    sys.exit(1)
"

echo "Sublyne Traffic Monitor startup completed"